"""Deep Manifold Transformation for Dimension Reduction (DMT)."""

from ._metadata import __version__, __author__, __email__, within_flit

if not within_flit():  # see function docstring on why this is there

    del within_flit

    # the actual API
    # (start with settings as several tools are using it)
    from ._settings import settings, Verbosity
    from . import tools as tl
    from . import logging

    from anndata import AnnData, concat
    from anndata import (
        read_h5ad,
        read_csv,
        read_excel,
        read_hdf,
        read_loom,
        read_mtx,
        read_text,
        read_umi_tools,
    )
    from .readwrite import read, read_10x_h5, read_10x_mtx, write, read_visium

    set_figure_params = settings.set_figure_params

    # has to be done at the end, after everything has been imported
    import sys

    sys.modules.update({f'{__name__}.{m}': globals()[m] for m in ['tl']})
    from ._utils import annotate_doc_types

    annotate_doc_types(sys.modules[__name__], 'scanpy')
    del sys, annotate_doc_types
