import torch


def Similarity(dist, rho, sigma_array, gamma, v=100):

    if torch.is_tensor(rho):
        dist_rho = (dist - rho) / sigma_array
    else:
        dist_rho = dist

    dist_rho[dist_rho < 0] = 0
    # Pij = torch.pow(
    #     gamma * torch.pow(
    #         (1 + dist_rho / v),
    #         -1 * (v + 1) / 2
    #         ) * torch.sqrt(torch.tensor(2 * 3.14)),
    #         2
    #     )
    Pij = gamma * gamma * torch.pow((1 + dist_rho / v), -1 * (v + 1)) * 2 * 3.14
    # print(Pij, Pij2)
    # input()
    P = Pij + Pij.t() - torch.mul(Pij, Pij.t())

    return P