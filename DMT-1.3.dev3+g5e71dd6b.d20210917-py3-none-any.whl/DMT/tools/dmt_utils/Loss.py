import torch
from torch import nn
from typing import Any
from .tool import CalGammaF, Distance_Squared
from .Similarity import Similarity


class Source(nn.Module):
    def __init__(
        self,
        v_input,
        fb,
        nb,
        device: Any,
    ):
        super(Source, self).__init__()

        self.device = device
        self.v_input = v_input
        self.gamma_input = CalGammaF(v_input)
        self._Similarity = Similarity
        self.l1_loss = nn.L1Loss()
        self.fb = fb
        self.nb = nb

    def _L2Loss(self, P, Q):
        losssum = torch.norm(P - Q, p=2) / P.shape[0]
        return losssum

    def _L3Loss(self, P, Q):
        losssum = torch.norm(P - Q, p=3) / P.shape[0]
        return losssum

    def _DistanceSquared(
        self,
        x,
    ):
        m, n = x.size(0), x.size(0)
        xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
        yy = xx.t()
        dist = xx + yy
        dist.addmm_(mat1=x, mat2=x.t(), beta=1, alpha=-2,)
        dist = dist.clamp(min=1e-12)
        # d[torch.eye(d.shape[0]) == 1] = 1e-12

        return dist
        
    def forward(self, input_data, latent_data, rho, sigma, v_latent):
        loss_ce = self.ITEM_loss(
            P=self._Similarity(
                dist=self._DistanceSquared(input_data),
                rho=rho,
                sigma_array=sigma,
                gamma=self.gamma_input,
                v=self.v_input),
            Q=self._Similarity(
                dist=self._DistanceSquared(latent_data),
                rho=0,
                sigma_array=1,
                gamma=CalGammaF(v_latent),
                v=v_latent)
        )

        return loss_ce


class LossV2(Source):
    def __init__(
        self,
        v_input,
        fb,
        nb,
        device: Any,
    ):
        super(LossV2, self).__init__(v_input=v_input, fb=fb, nb=nb, device=device)
        self.ITEM_loss = self._TwowaydivergenceLoss

    def _TwowaydivergenceLoss(self, P, Q):
        EPS = 1e-12
        P_ = P[torch.eye(P.shape[0]) == 0] * (1 - 2 * EPS) + EPS
        Q_ = Q[torch.eye(P.shape[0]) == 0] * (1 - 2 * EPS) + EPS
        losssum1 = (P_ * torch.log(Q_ + EPS)).mean()
        losssum2 = ((1 - P_) * torch.log(1 - Q_ + EPS)).mean()
        losssum = -1 * (losssum1 + losssum2)

        if torch.isnan(losssum):
            input('stop and find nan')
        return losssum


class LossV3(Source):
    def __init__(
        self,
        v_input,
        fb,
        nb,
        device: Any,
    ):
        super(LossV2, self).__init__(v_input=v_input, fb=fb, nb=nb, device=device)
        self.ITEM_loss = self._TwowaydivergenceLoss

    def _TwowaydivergenceLoss(self, P, Q):
        EPS = 1e-22
        # P_ = P[torch.eye(P.shape[0]) == 0] * (1 - 2 * EPS) + EPS
        # Q_ = Q[torch.eye(P.shape[0]) == 0] * (1 - 2 * EPS) + EPS
        selected_index_near = (P > Q) & (P > self.nb)
        selected_index_far = (P < Q) & (P < self.fb)
        losssum1 = (P * torch.log(Q + EPS))[selected_index_near].sum()
        losssum2 = ((1 - P) * torch.log(1 - Q + EPS))[selected_index_far].sum()
        losssum = -1 * (losssum1 + losssum2) / (selected_index_near.sum() + selected_index_far.sum())

        if torch.isnan(losssum):
            input('stop and find nan')
        return losssum


class SourceV1(nn.Module):
    def __init__(self, dist, device, rho, sigma, gammaList, vList, NetworkStructure, perplexity) -> None:
        super(SourceV1, self).__init__()
        self.dist = dist
        self.device = device
        self.rho = rho
        self.sigma = sigma
        self.gammaList = gammaList
        self.vList = vList
        self.ReconstructionLoss = nn.MSELoss()
        self.NetworkStructure = NetworkStructure
        self.perplexity = perplexity

    def CalPt(self, dist, rho, sigma_array, gamma, pow=2, v=100, split=1):
        if torch.is_tensor(rho):
            dist_rho = (dist - rho.reshape(-1, 1)) / sigma_array.reshape(-1, 1)
        else:
            dist_rho = dist

        dist_rho[dist_rho < 0] = 0
        sample_index_list = torch.linspace(0, dist.shape[0], int(split) + 1)
        for i in range(split):
            dist_rho_c = dist_rho[int(sample_index_list[i]
                                      ):int(sample_index_list[i + 1])]
            if v > 200:
                Pij = torch.pow(
                    input=torch.exp(-1 * dist_rho_c),
                    exponent=pow
                )
            else:
                Pij_c = torch.pow(
                    gamma * torch.pow((1 + dist_rho_c / v), -1 * (v + 1) / 2) * torch.sqrt(torch.tensor(2 * 3.14)), pow)
            if i == 0:
                Pij = Pij_c
            else:
                Pij = torch.cat([Pij, Pij_c], dim=0)
        P = Pij + Pij.t() - torch.mul(Pij, Pij.t())

        return P

    def CE(self, P, Q):
        P = P.detach()
        EPS = 1e-12
        losssum1 = (P * torch.log(Q + EPS)).mean()
        losssum2 = ((1 - P) * torch.log(1 - Q + EPS)).mean()
        losssum = -1 * (losssum1 + losssum2)

        if torch.isnan(losssum):
            raise ValueError('stop and find nan')
        return losssum


class Loss_v110(SourceV1):
    def __init__(self, dist, device, rho, sigma, gammaList, vList, NetworkStructure, perplexity) -> None:
        super().__init__(dist, device, rho, sigma, gammaList, vList, NetworkStructure, perplexity)
        self.P = self.CalPt(self.dist.to(device), self.rho.to(device),
                            self.sigma[0],
                            gamma=self.gammaList[0],
                            v=self.vList[0],
                            split=1).float().detach().to(self.device)

    def forward(self, input_data_model, latentList, reconstruction, input_data_index):
        loss_ce = self.CE(P=self.P[input_data_index][:, input_data_index],
                          Q=self.CalPt(dist=Distance_Squared(latentList, latentList),
                                       rho=0,
                                       sigma_array=1,
                                       gamma=self.gammaList[-1],
                                       v=self.vList[-1]))
        loss_rc = self.ReconstructionLoss(
            reconstruction,
            input_data_model)
        return loss_ce, loss_rc / 10


class Loss_v111(SourceV1):
    def forward(self, input_data_model, latentList, reconstruction, input_data_index):
        loss_ce = self.CE(
            P=self.CalPt(dist=self.dist[input_data_index][:, input_data_index].to(self.device),
                         rho=self.rho[input_data_index].to(self.device),
                         sigma_array=self.sigma[0][input_data_index],
                         gamma=self.gammaList[0],
                         v=self.vList[0]),
            Q=self.CalPt(dist=Distance_Squared(latentList, latentList),
                         rho=0,
                         sigma_array=1,
                         gamma=self.gammaList[-1],
                         v=self.vList[-1]))
        loss_rc = self.ReconstructionLoss(
            reconstruction,
            input_data_model)
        return loss_ce, loss_rc / 10
