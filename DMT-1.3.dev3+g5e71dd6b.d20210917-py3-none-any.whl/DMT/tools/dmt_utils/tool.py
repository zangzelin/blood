from itertools import product
import logging
import subprocess

import numpy as np
import matplotlib.pyplot as plt
import imageio
import random as rd
import time
import torch
import os
from multiprocessing import Pool
import math
from numba import cuda


def adjust_learning_rate(optimizer, lr):
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def LearningRateScheduler(loss_his, optimizer, lr_base):

    loss_his = np.array(loss_his)
    num_shock = np.sum((loss_his[:-1] - loss_his[1:]) < 0)
    if num_shock > 0.40 * loss_his.shape[0] and lr_base > 1e-4:
        lr_new = lr_base * 0.8
        adjust_learning_rate(optimizer, lr_new)
    else:
        lr_new = lr_base
    logging.info('*** lr {} -> {}  ***'.format(lr_base, lr_new))
    logging.info('num_shock', num_shock)
    return lr_new


def SaveData(input, latent, label, dist=None, path='', name=''):

    if type(input) == torch.Tensor:
        input = input.detach().cpu().numpy()
    if type(latent) == torch.Tensor:
        latent = latent.detach().cpu().numpy()
    if type(label) == torch.Tensor:
        label = label.detach().cpu().numpy()

    # path = '/usr/data/DMT_Nature/old/' + path

    numEpoch = int(name.split('train_epoch')[1])
    np.save(
        path + name + 'latent.npy',
        latent,
    )

    if numEpoch < 1:
        np.save(
            path + name + 'input.npy',
            input.astype(np.float16),
        )
        np.save(
            path + name + 'label.npy',
            label.astype(np.float16),
        )    # comment if not use label
        if dist is not None:
            np.save(
                path + name + 'dist.npy',
                dist.detach().cpu().numpy().astype(np.float16),
            )


class GIFPloter():
    def __init__(self, ):
        self.path_list = []

    def PlotOtherLayer(
        self,
        fig,
        data,
        label,
        title='',
        fig_position0=1,
        fig_position1=1,
        fig_position2=1,
        s=0.1,
        graph=None,
        link=None,
        #    latent=None,
    ):
        from sklearn.decomposition import PCA

        color_list = []
        for i in range(label.shape[0]):
            color_list.append(int(label[i]))

        if data.shape[1] > 3:
            pca = PCA(n_components=2)
            data_em = pca.fit_transform(data)
        else:
            data_em = data

        # data_em = data_em-data_em.mean(axis=0)

        if data_em.shape[1] == 3:
            ax = fig.add_subplot(fig_position0,
                                 fig_position1,
                                 fig_position2,
                                 projection='3d')

            ax.scatter(data_em[:, 0],
                       data_em[:, 1],
                       data_em[:, 2],
                       c=color_list,
                       s=s,
                       cmap='rainbow')

        if data_em.shape[1] == 2:
            ax = fig.add_subplot(fig_position0, fig_position1, fig_position2)

            if graph is not None:
                self.PlotGraph(data, graph, link)

            s = ax.scatter(data_em[:, 0],
                           data_em[:, 1],
                           c=label,
                           s=s,
                           cmap='rainbow')
            plt.axis('equal')
            if None:
                list_i_n = len(set(label.tolist()))
                # print(list_i_n)
                legend1 = ax.legend(*s.legend_elements(num=list_i_n),
                                    loc="upper left",
                                    title="Ranking")
                ax.add_artist(legend1)
        # ax.spines['top'].set_visible(False)
        # ax.spines['right'].set_visible(False)
        # ax.spines['bottom'].set_visible(False)
        # ax.spines['left'].set_visible(False)
        # plt.xticks([])
        # plt.yticks([])
        # # plt.title(title)

    def AddNewFig(self,
                  latent,
                  label,
                  link=None,
                  graph=None,
                  his_loss=None,
                  title_='',
                  path='./',
                  dataset=None):

        fig = plt.figure(figsize=(5, 5))

        if latent.shape[0] <= 1000:
            s = 3
        elif latent.shape[0] <= 10000:
            s = 1
        else:
            s = 0.1

        if latent.shape[1] <= 3:
            self.PlotOtherLayer(fig,
                                latent,
                                label,
                                title=title_,
                                fig_position0=1,
                                fig_position1=1,
                                fig_position2=1,
                                graph=graph,
                                link=link,
                                s=s)
            plt.tight_layout()
            path_c = path + title_
            # self.path_list.append(path_c)
        elif 'coil20' in dataset:
            imageAll = np.array([])
            # for i in range(4):
            imgL1 = np.concatenate(
                [latent[j].reshape(128, 128) for j in range(0, 5)], axis=1)
            imgL2 = np.concatenate(
                [latent[j].reshape(128, 128) for j in range(5, 10)], axis=1)
            imgL3 = np.concatenate(
                [latent[j].reshape(128, 128) for j in range(10, 15)], axis=1)
            imgL4 = np.concatenate(
                [latent[j].reshape(128, 128) for j in range(15, 20)], axis=1)
            imageAll = np.concatenate([imgL1, imgL2, imgL3, imgL4], axis=0)

            plt.imshow(imageAll)
        elif 'mnist' in dataset:
            imageAll = np.array([])
            # for i in range(4):
            imgL1 = np.concatenate(
                [latent[j].reshape(28, 28) for j in range(0, 5)], axis=1)
            imgL2 = np.concatenate(
                [latent[j].reshape(28, 28) for j in range(5, 10)], axis=1)
            imgL3 = np.concatenate(
                [latent[j].reshape(28, 28) for j in range(10, 15)], axis=1)
            imgL4 = np.concatenate(
                [latent[j].reshape(28, 28) for j in range(15, 20)], axis=1)
            imageAll = np.concatenate([imgL1, imgL2, imgL3, imgL4], axis=0)

            plt.imshow(imageAll)
        elif 'coil100' in dataset:
            imageAll = np.array([])
            # for i in range(4):
            imgL1 = np.concatenate(
                [latent[j].reshape(128, 128, 3) for j in range(0, 5)], axis=1)
            imgL2 = np.concatenate(
                [latent[j].reshape(128, 128, 3) for j in range(5, 10)], axis=1)
            imgL3 = np.concatenate(
                [latent[j].reshape(128, 128, 3) for j in range(10, 15)], axis=1)
            imgL4 = np.concatenate(
                [latent[j].reshape(128, 128, 3) for j in range(15, 20)], axis=1)
            imageAll = np.concatenate([imgL1, imgL2, imgL3, imgL4], axis=0)

            plt.imshow(imageAll)
        plt.tight_layout()
        path_c = path + title_
        self.path_list.append(path_c)

        plt.savefig(path_c, dpi=400)
        plt.close()

    def PlotGraph(self, latent, graph, link):

        for i in range(graph.shape[0]):
            for j in range(graph.shape[0]):
                if graph[i, j]:
                    p1 = latent[i]
                    p2 = latent[j]
                    lik = link[i, j]
                    plt.plot([p1[0], p2[0]], [p1[1], p2[1]],
                             'gray',
                             lw=1 / lik)
                    if lik > link.min() * 1.01:
                        plt.text((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2,
                                 str(lik)[:4],
                                 fontsize=5)

    def SaveGIF(self):

        gif_images = []
        for i, path_ in enumerate(self.path_list):
            # print(path_)
            gif_images.append(imageio.imread(path_))
            # if i > 0 and i < len(self.path_list)-2:
            #     os.remove(path_)

        imageio.mimsave(path_[:-4] + ".gif", gif_images, fps=5)


def SetSeed(seed):
    """function used to set a random seed

    Arguments:
        seed {int} -- seed number, will set to torch, random and numpy
    """
    SEED = seed
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    rd.seed(SEED)
    np.random.seed(SEED)


def GetPath(name=''):

    rest = time.strftime("%Y%m%d%H%M%S_", time.localtime())

    path = 'log/' + rest[:20] + name
    if not os.path.exists(path):
        os.makedirs(path)

    return path + '/'


def SaveParam(path, param):
    import json
    paramDict = param
    paramStr = json.dumps(paramDict, indent=4)
    # paramStr = json.dumps(paramStr)

    print(paramStr, file=open(path + '/param.txt', 'a'))


class AutoTrainer():
    def __init__(self,
                 changeList,
                 paramName,
                 mainFunc,
                 deviceList=[4, 5, 6, 7],
                 poolNumber=4,
                 name='AutoTrainer',
                 waittime=1):
        self.paramName = paramName
        self.mainFunc = mainFunc
        self.changeList = changeList
        self.deviceList = deviceList
        self.poolNumber = poolNumber
        self.name = name
        self.waittime = waittime

        self.loopList = list(product(*tuple(changeList)))
        # print(self.loopList)
        # input()

    def Run(self, ):

        poolLeftNumber = self.poolNumber - 1
        # gpunum = 0
        for i, item in enumerate(self.loopList):

            txtDevice = "CUDA_VISIBLE_DEVICES={} ".format(
                self.deviceList[i % len(self.deviceList)])
            txtmain = 'python -u ' + self.mainFunc
            txtparam = ''
            for j, param in enumerate(self.paramName):
                txtparam += '--{} {} '.format(param, item[j])
            txtname = '--name ' + self.name + txtparam.replace(
                ' ', '_').replace('--', '_')

            txt = ' '.join([txtDevice, txtmain, txtparam, txtname])
            print(txt)
            # input()
            # os.system(txt)

            if poolLeftNumber == 0:
                print('continue left:', poolLeftNumber)
                poolLeftNumber = self.poolNumber - 1
                child = subprocess.Popen(txt, shell=True)
                child.wait()
                # subprocess.Popen()
            else:
                print('wait left:', poolLeftNumber)
                child = subprocess.Popen(txt, shell=True)
                # child.wait(2)
                poolLeftNumber -= 1
            time.sleep(self.waittime)


class PoolRunner(object):
    def __init__(self,
                 number_point,
                 perplexity,
                 dist,
                 rho,
                 gamma,
                 v,
                 pow=2,
                 func_new=None,
                 use_gpu=False,
                 gpuid=0
                 ):
        self.func = func_new if func_new else func_tdis

        if use_gpu:
            logging.info('Start useing GPU to calculate sigma')
            self.sigma_array = singleStream(gpuid, number_point, 30000, dist, rho, perplexity, gamma, v, pow)
        else:
            logging.info('Start calculate sigma')
            pool = Pool(processes=30)
            result = []
            for dist_row in range(number_point):
                result.append(pool.apply_async(sigma_binary_search, (perplexity, dist[dist_row], rho[dist_row], gamma, v, pow, self.func)))
            pool.close()
            pool.join()
            sigma_array = []
            for i in result:
                sigma_array.append(i.get())
            self.sigma_array = np.array(sigma_array)
        logging.info("Mean sigma = " + str(np.mean(self.sigma_array)))
        logging.info('finish calculate sigma')
        # print(self.sigma_array)
        # input()

    def Getout(self, ):
        return self.sigma_array


def singleStream(gpuId: int, n: int, batchsize: int, dist: np.ndarray, rho: np.ndarray, k=10, gamma=0.39794618693589373, v=100, power=2.0, block_per_gride=None, thread_per_block=None):
    """
    单流方法
    """
    cuda.select_device(gpuId)
    # if thread_per_block is None:
    #     thread_per_block = 640 if "2080 Ti" in str(cuda.get_current_device()) else 1024
    thread_per_block = 640
    block_per_gride = math.ceil(batchsize / thread_per_block)
    rho_gpu = cuda.to_device(rho)
    sigma_cpu = np.zeros(n)
    sigma_gpu = cuda.device_array(batchsize)
    for i in range(0, n, batchsize):
        if i + batchsize > n:
            # _batchsize = n - i
            # sigma_gpu = cuda.to_device(np.zeros(_batchsize, dtype=np.float32))
            dist_gpu = cuda.to_device(dist[i:])
            # print("data ready, time:", time.time() - d)

            sigma_binary_search_gpu[block_per_gride, thread_per_block](k, dist_gpu, rho_gpu[i:], gamma, v, power, sigma_gpu)
            sigma_cpu[i:] = sigma_gpu.copy_to_host()[: n - i]
        else:
            # sigma_gpu = cuda.to_device(np.zeros(batchsize, dtype=np.float32))
            dist_gpu = cuda.to_device(dist[i: i + batchsize])
            # print("data ready, time:", time.time() - d)

            sigma_binary_search_gpu[block_per_gride, thread_per_block](k, dist_gpu, rho_gpu[i: i + batchsize], gamma, v, power, sigma_gpu)
            sigma_cpu[i: i + batchsize] = sigma_gpu.copy_to_host()

        cuda.synchronize()
    return sigma_cpu


def func_tdis(sigma, dist_row_line, rho_line, gamma, v, pow):
    d = (dist_row_line - rho_line) / sigma
    d[d < 0] = 0
    p = torch.pow(
        gamma * torch.pow((1 + d / v), -1 * (v + 1) / 2) * np.sqrt(2 * 3.14),
        pow)
    return torch.pow(2, torch.sum(p))


def sigma_binary_search(fixed_k, dist_row_line, rho_line, gamma, v, pow=2, func=func_tdis):
    """
    Solve equation k_of_sigma(sigma) = fixed_k
    with respect to sigma by the binary search algorithm
    """
    sigma_lower_limit = 0
    sigma_upper_limit = 1000
    for i in range(20):
        approx_sigma = (sigma_lower_limit + sigma_upper_limit) / 2
        k_value = func(approx_sigma,
                       dist_row_line,
                       rho_line,
                       gamma,
                       v,
                       pow=pow)
        if k_value < fixed_k:
            sigma_lower_limit = approx_sigma
        else:
            sigma_upper_limit = approx_sigma
        if np.abs(fixed_k - k_value) <= 1e-4:
            break
    return approx_sigma

# 老方法
@cuda.jit
def sigma_binary_search_gpu(fixed_k, dist, rho, gamma, v, pow, sigma):
    """
    Solve equation k_of_sigma(sigma) = fixed_k
    with respect to sigma by the binary search algorithm
    """
    start_x = cuda.grid(1)
    stride_x = cuda.gridsize(1)
    sigma_lower_limit = 0
    sigma_upper_limit = 1000
    # r = cuda.local.array(1, float32)
    for i in range(start_x, dist.shape[0], stride_x):
        for x in range(20):
            approx_sigma = (sigma_lower_limit + sigma_upper_limit) / 2

            r = 0
            for j in range(dist.shape[1]):
                tmp = (dist[i][j] - rho[i]) / approx_sigma
                d = 0 if tmp < 0 else tmp
                r += func_gpu(gamma, d, v, pow)
                # cuda.atomic.add(s, i, func_gpu(gamma, d, v, pow))
                # s1[i][j] = math.pow(gamma * math.pow((1 + d / v), -1 * (v + 1) / 2) * math.sqrt(2 * 3.14), pow)

            k_value = math.pow(2, r)
            if k_value < fixed_k:
                sigma_lower_limit = approx_sigma
            else:
                sigma_upper_limit = approx_sigma
            if abs(fixed_k - k_value) <= 1e-4:
                break

        sigma[i] = approx_sigma

    cuda.syncthreads()


@cuda.jit(device=True)
def func_gpu(gamma, d, v, pow):
    return math.pow(gamma * math.pow((1 + d / v), -1 * (v + 1) / 2) * math.sqrt(2 * 3.14), pow)


class Nushadular():
    def __init__(self,
                 nu_start=0.001,
                 nu_end=100,
                 epoch_start=300,
                 epoch_end=750) -> None:
        super().__init__()

        s = np.log10(nu_start)
        e = np.log10(nu_end)
        self.vListForEpoch = np.concatenate([
            np.zeros((epoch_start, )) + 10**s,
            np.logspace(s, e, epoch_end - epoch_start),
            np.zeros((17001, )) + 10**e,
        ])

    def __getitem__(self, epoch):
        return self.vListForEpoch[epoch]


def CalGammaF(vList):
    from scipy import special
    if isinstance(vList, list):
        out = []
        for v in vList:
            a = special.gamma((v + 1) / 2)
            b = np.sqrt(v * np.pi) * special.gamma(v / 2)
            out.append(a / b)
    else:
        a = special.gamma((vList + 1) / 2)
        b = np.sqrt(vList * np.pi) * special.gamma(vList / 2)
        out = a / b

    return out


def Distance_Squared(x, y):
    m, n = x.size(0), x.size(0)
    xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
    yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
    dist = xx + yy
    dist.addmm_(mat1=x, mat2=y.t(), beta=1, alpha=-2,)
    dist = dist.clamp(min=1e-12)
    dist[torch.eye(dist.shape[0]) == 1] = 1e-12
    return dist
