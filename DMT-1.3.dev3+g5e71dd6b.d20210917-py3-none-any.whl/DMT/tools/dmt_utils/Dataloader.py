import torch
from torch import tensor
from torch.utils.data import Dataset
import joblib
import numpy as np
import math
import logging
import torch.distributed as dist

__all__ = ['DatasetV1', 'DatasetV2']


class myDataset(Dataset):
    def __init__(
        self,
        data: tensor,
        label: tensor,
        batch_size: int,
        device: torch.device,
        seed: int = 0
    ):
        self.data = data.float()
        self.label = label.float()
        self.batch_size = batch_size
        self.device = device
        self.inputdim = self.data[0].shape
        self.n_point = len(data)
        self.seed = seed
        self.g = torch.Generator(device=self.device)

        if torch.cuda.device_count() > 1:
            # 多GPU训练的数据切割
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            self.num_replicas = dist.get_world_size()
            self.rank = dist.get_rank()
            self.num_samples = math.ceil(self.n_point / self.num_replicas)  # type: ignore

    def SaveData(self, path):
        joblib.dump(
            value=[
                np.array(self.data.detach().cpu()),
                np.array(self.label.detach().cpu())],
            filename=path + 'data_label.gz',
        )

    def __len__(self):
        return len(self.data)

    def reset(self, epoch):
        self.g.manual_seed(self.seed + epoch)
        self.index_all = torch.randperm(self.n_point, generator=self.g, device=self.device).long()  # type: ignore
        # self.index_all_local = self.index_all[self.rank * self.num_samples: (self.rank + 1) * self.num_samples]
        self.index_all_local = self.index_all[self.rank:self.n_point:self.num_replicas]
        self.c_use = 0
        self.c_use_end = 1
        self.batch_idx = 0
        self.c_use_end = min(self.c_use + self.batch_size, self.num_samples)

    def epochend(self):
        return self.c_use != self.c_use_end

    def load(self,):
        index = self.index_all_local[self.c_use:self.c_use_end].long().to(self.device)
        self.c_use = self.c_use_end
        self.c_use_end = min(self.c_use + self.batch_size, self.num_samples)
        self.batch_idx += 1
        return self.batch_idx - 1, index

    def loadAll(self,):
        index = self.index_all[self.c_use:self.c_use_end].long().to(self.device)
        self.c_use = self.c_use_end
        self.c_use_end = min(self.c_use + self.batch_size, self.num_samples)
        self.batch_idx += 1
        return self.batch_idx - 1, index

    def toDevice(self):
        self.data = self.data.to(self.device)
        self.label = self.label.to(self.device)


class DatasetV1(myDataset):
    def __init__(self, data: tensor, label: tensor, batch_size: int, device: torch.device):
        super().__init__(data, label, batch_size, device)
        from .tool import Distance_Squared
        logging.info('Start to Distance_squared')
        self.dist = Distance_Squared(data, data).float()
        torch.cuda.empty_cache()

    def __getitem__(self, index):
        data_item = self.data[index].float().to(self.device)
        label_item = self.label[index].to(self.device)
        return data_item, None, label_item


class DatasetV2(myDataset):
    def __init__(self, data: tensor, label: tensor, batch_size: int, device: torch.device, model_type='mlp'):
        super().__init__(data, label, batch_size, device)
        self.model_type = model_type

    def __getitem__(self, index):

        data_item = self.data[index]
        label_item = self.label[index].to(self.device)

        if self.model_type == 'mlp' and len(data_item.shape) >= 2:
            input_data_model = data_item.reshape((data_item.shape[0], -1))
            input_data_loss = input_data_model
        if self.model_type == 'cnn' and len(data_item.shape) < 4:
            s = data_item.shape
            input_data_model = data_item.reshape((s[0], 1, s[1], s[2])).expand((s[0], 3, s[1], s[2]))
            input_data_loss = data_item.reshape((data_item.shape[0], -1))
        if self.model_type == 'cnn' and len(data_item.shape) == 4:
            # input_data_model = data_item
            input_data_model = data_item.transpose(1, 3).transpose(2, 3)
            input_data_loss = data_item.reshape((data_item.shape[0], -1))

        input_data_model = input_data_model.float().to(self.device)
        input_data_loss = input_data_loss.float().to(self.device)

        return input_data_model, input_data_loss, label_item
