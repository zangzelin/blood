# a pytorch based lisv2 code
# author: zelinzang
# email: zangzelin@gmail.com

import torch
import torch.autograd
from torch import nn, tensor
from .tool import Nushadular, CalGammaF, PoolRunner
from .Dataloader import DatasetV1, DatasetV2
import functools
from .ResNet_ import resnet18
import logging
import warnings
from typing import Any
import math
from sklearn.metrics import pairwise_distances
from pynndescent import NNDescent


class base(nn.Module):
    def __init__(
        self,
        dataset,
        device,
        args,
        func_new
    ):
        super(base, self).__init__()
        warnings.filterwarnings(action='ignore', message='overflow encountered in power', category=RuntimeWarning)

        with torch.no_grad():
            self.dataset = dataset

            self.epoch = 0
            self.args = args
            self.func_new = func_new
            self.device = device
            self.dataset_name = args['data_name']
            self.perplexity = args['perplexity']
            self.NetworkStructure = args['NetworkStructure']
            self.NetworkStructure[0] = functools.reduce(lambda x, y: x * y, dataset.inputdim)

            self.vList = [self.args['v_input']] + [1] * (len(self.args['NetworkStructure']) - 1)   # smile 100->0.0001, 0.0001good for smile and circle  #100 means normal distribution for input space
            self.gammaList = CalGammaF(self.vList)
            self.rho, self.sigmaListlayer = self.InitSigmaSearchEverySample(self.gammaList, self.vList)

            logging.info('start Init network')
            self.InitNetwork()
            # logging.info('start SpectralEmbedding')
            # self.CalSpectralEmbeddingInitAim(data)
            logging.info('init LISV2_MLP mocol model, gaama is: {}'.format(self.gammaList))

    def InitSigmaSearchEverySample(
        self,
        gammaList,
        vList,
    ):

        distC = torch.clone(self.dataset.dist)
        distC[distC.le(1e-11)] = 1e16
        rho, _ = torch.min(distC, dim=1)
        # rho = torch.zeros((distC.shape[0]))

        sigmaListlayer = [0] * len(self.NetworkStructure)

        r = PoolRunner(self.dataset.n_point,
                       self.perplexity,
                       self.dataset.dist.detach().cpu().numpy(),
                       rho.detach().cpu().numpy(),
                       gammaList[0],
                       vList[0],
                       pow=self.args['pow'],
                       func_new=self.func_new,
                       use_gpu=self.args['sigma'])
        sigmaListlayer[0] = torch.tensor(r.Getout()).to(self.device)

        std_dis = torch.std(rho) / math.sqrt(self.dataset.data.shape[1])
        logging.info('std: {}'.format(std_dis))

        if std_dis > 0.2:
            for i in range(1, len(self.NetworkStructure)):
                sigmaListlayer[i] = torch.zeros(self.dataset.n_point,
                                                device=self.device) + 1
        else:
            for i in range(0, len(self.NetworkStructure)):
                sigmaListlayer[i] = torch.zeros(
                    self.dataset.n_point,
                    device=self.device) + sigmaListlayer[0].mean() * 5
        return rho, sigmaListlayer

    def InitNetwork(self, ):
        self.encoder = nn.ModuleList()
        for i in range(len(self.NetworkStructure) - 1):
            self.encoder.append(
                nn.Linear(self.NetworkStructure[i],
                          self.NetworkStructure[i + 1]))
            if i != len(self.NetworkStructure) - 2:
                self.encoder.append(nn.LeakyReLU(0.1))
        self.encoder.to(self.device)

        self.decoder = nn.ModuleList()
        for i in range(len(self.NetworkStructure) - 1, 0, -1):
            self.decoder.append(
                nn.Linear(self.NetworkStructure[i],
                          self.NetworkStructure[i - 1]))
            if i != 1:
                self.decoder.append(nn.LeakyReLU(0.1))
        # Map output to range (0, 1) for image datasets
        if('mnist' in self.dataset_name or 'coil' in self.dataset_name):
            self.decoder.append(nn.Sigmoid())
        self.decoder.to(self.device)

    def ChangeVList(self):
        epoch = self.epoch
        self.vCurent = self.vListForEpoch[epoch]
        newVList = [self.args['v_input']]
        for i in range(len(self.NetworkStructure) - 1):
            newVList.append(self.vCurent)
        self.vList = newVList
        self.gammaList = CalGammaF(newVList)

    def forward(self, input_data, index=None):
        self.ChangeVList()
        # x = self.dataset.data[input_data_index.long()]
        x = input_data
        for i, layer in enumerate(self.encoder):
            x = layer(x)

        return x

    def Generate(self, latent):

        x = latent
        for i, layer in enumerate(self.decoder):
            x = layer(x)

        return x

    def test(self, input_data):

        self.ChangeVList()
        x = input_data.to(self.device)

        for i, layer in enumerate(self.encoder):
            x = layer(x)

        return [x]


class ELIS110(base):
    def __init__(self, dataset: DatasetV1, device, args, func_new=None):
        super().__init__(dataset, device, args, func_new=func_new)
        with torch.no_grad():
            self.vListForEpoch = Nushadular(self.args['vs'], self.args['ve'], 1000, 3000)
            torch.cuda.empty_cache()


class ELIS111(base):
    def __init__(self, dataset: DatasetV1, device, args, func_new=None):
        super().__init__(dataset, device, args, func_new=func_new)
        with torch.no_grad():
            self.vListForEpoch = Nushadular(self.args['vs'], self.args['ve'], 200, 600)
            torch.cuda.empty_cache()


class LISV2(torch.nn.Module):
    def __init__(
        self,
        dataset: DatasetV2,
        device: Any,
        args,
        func_new=None,
        K=15,
        same_sigma=True,
        metric='euclidean',
        model_type='mlp'
    ):

        super(LISV2, self).__init__()
        with torch.no_grad():
            self.dataset = dataset
            self.device = device
            self.args = args
            self.data_name = args['data_name']
            self.perplexity = args['perplexity']
            self.v_input = args['v_input']
            self.DEC = args['DEC']
            self.NetworkStructure = args['NetworkStructure']
            self.NetworkStructure[0] = functools.reduce(lambda x, y: x * y, dataset.inputdim)
            self.n_dim = 2

            self.func_new = func_new
            self.K = K
            self.same_sigma = same_sigma
            self.metric = metric
            self.model_type = model_type

            self._Pretreatment()

            if model_type == 'mlp':
                self.model_type = model_type
                self.InitNetworkMLP()
            elif model_type == 'cnn':
                self.model_type = model_type
                self.InitNetworkCNN()
            else:
                raise ValueError("model_type must be mlp or cnn")
            torch.cuda.empty_cache()

    def InitNetworkMLP(self):
        self.encoder = nn.ModuleList()
        for i in range(len(self.NetworkStructure) - 1):
            self.encoder.append(
                nn.Linear(self.NetworkStructure[i],
                          self.NetworkStructure[i + 1]))
            if i != len(self.NetworkStructure) - 2:
                self.encoder.append(nn.LeakyReLU())
        self.encoder.to(self.device)

        if self.DEC:
            self.decoder = nn.ModuleList()
            for i in range(len(self.NetworkStructure) - 1, 0, -1):
                self.decoder.append(
                    nn.Linear(self.NetworkStructure[i], self.NetworkStructure[i - 1]))
                if i != 1:
                    self.decoder.append(nn.LeakyReLU(0.1))
            self.decoder.to(self.device)
            # Map output to range (0, 1) for image datasets
            # if('mnist' in self.dataset_name or 'coil' in self.dataset_name):
            #     self.decoder.append(nn.Sigmoid())

    def InitNetworkCNN(self):
        self.encoder = resnet18(num_classes=self.n_dim).to(self.device)

    def forward(self, input_data, index=None):

        # x = self.dataset.data[input_data_index.long()]
        if self.model_type == 'cnn':
            x = self.encoder(input_data)
        else:
            x = input_data
            for i, layer in enumerate(self.encoder):
                x = layer(x)
        return x

    def decf(self, latent, index=None):
        # if self.model_type == 'cnn':
        #     x=self.encoder(data)
        # else:
        x = latent
        for i, layer in enumerate(self.decoder):
            x = layer(x)
        return x

    def Generate(self, latent, index=None):

        x = latent.reshape(latent.shape[0], -1)
        for i, layer in enumerate(self.decoder):
            x = layer(x)

        return [x]

    def _Pretreatment(self, ):
        if self.dataset.data.shape[0] > 5000:
            rho, sigma = self._initKNN(
                self.dataset.data, perplexity=self.perplexity, v_input=self.v_input)
        else:
            # rho, sigma = self._initPairwiseMahalanobis(
            rho, sigma = self._initPairwise(
                self.dataset.data, perplexity=self.perplexity, v_input=self.v_input)

        self.sigma = sigma
        self.rho = rho

    def _initPairwise(self, X, perplexity, v_input):
        logging.info('use pairwise mehtod to find the sigma')
        dist = torch.pow(tensor(pairwise_distances(X.reshape((X.shape[0], -1)),
                                                   n_jobs=-1,
                                                   metric=self.metric)), 2)
        rho = self._CalRho(dist)

        r = PoolRunner(
            number_point=X.shape[0],
            perplexity=perplexity,
            dist=dist,
            rho=rho,
            gamma=CalGammaF(v_input),
            v=v_input,
            pow=2,
            func_new=self.func_new,
            use_gpu=self.args['sigma'])
        sigma = tensor(r.Getout())

        std_dis = torch.std(rho) / math.sqrt(X.shape[1])
        logging.info('std_dis: ' + str(std_dis))
        if std_dis < 0.20 or self.same_sigma:
            # sigma[:] = sigma.mean() * 5
            sigma[:] = sigma.mean()
            rho[:] = 0

        return rho, sigma

    def _initKNN(self, X, perplexity, v_input, K=500):
        logging.info('use kNN mehtod to find the sigma')

        X_rshaped = X.reshape((X.shape[0], -1))
        index = NNDescent(X_rshaped, n_jobs=-1, metric=self.metric)
        neighbors_index, neighbors_dist = index.query(X_rshaped, k=K)
        neighbors_dist = torch.pow(tensor(neighbors_dist), 2)
        rho = neighbors_dist[:, 1]

        r = PoolRunner(
            number_point=X.shape[0],
            perplexity=perplexity,
            dist=neighbors_dist,
            rho=rho,
            gamma=CalGammaF(v_input),
            v=v_input,
            pow=2)
        sigma = tensor(r.Getout())

        std_dis = torch.std(rho) / math.sqrt(X.shape[1])
        logging.info('std_dis: ' + str(std_dis))
        if std_dis < 0.20 or self.same_sigma:
            # sigma[:] = sigma.mean() * 5
            sigma[:] = sigma.mean()
        return rho, sigma

    def _CalRho(self, dist):
        distC = torch.clone(dist)
        distC[distC.le(1e-11)] = 1e16
        rho, _ = torch.min(distC, dim=1)
        return rho

#     def _PretreatmentMaskAndDistance(self, K=15, epsilon=2):
#         if K is not None:
#             self.K = K
#             self.dis_data, self.kNN_data = self.KNNGraph(
#                 torch.from_numpy(self.data).to(self.device))
#         else:
#             self.epsilon = epsilon
#             self.dis_data, self.kNN_data = self.Epsilonball(
#                 torch.from_numpy(self.data).to(self.device), epsilon)

#         # self.sigma = sigma
#         # self.rho = rho

#     def KNNGraph(self, data, k=15):

#         """
#         another function used to calculate the distance between point pairs and determine the neighborhood
#         Arguments:
#             data {tensor} -- the train data
#         Outputs:
#             d {tensor} -- the distance between point pairs
#             kNN_mask {tensor} a mask used to determine the neighborhood of every data point
#         """

#         if self.K < 1:
#             k = int(self.K * data.shape[0])
#         else:
#             k = self.K
#         batch_size = data.shape[0]

#         x = data.to(self.device)
#         y = data.to(self.device)
#         m, n = x.size(0), y.size(0)
#         xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
#         yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
#         dist = xx + yy
#         # dist.addmm_(1, -2, x, y.t())
#         dist = torch.addmm(dist, mat1=x, mat2=y.t(), beta=1, alpha=-2)
#         d = dist.clamp(min=1e-8).sqrt()  # for numerical stabili

#         s_, indices = torch.sort(d, dim=1)
#         indices = indices[:, :k + 1]
#         kNN_mask = torch.zeros(
#             (batch_size, batch_size,),
#             device=self.device).scatter(1, indices, 1)
#         kNN_mask[torch.eye(kNN_mask.shape[0], dtype=int)] = 0

#         return d, kNN_mask.bool()

#     def _initPairwiseMahalanobis(self, X, perplexity, v_input):

#         distold = pairwise_distances(X.reshape((X.shape[0], -1)), n_jobs=-1)

#         dist = np.zeros((X.shape[0], X.shape[0]))
#         for i in range(dist.shape[0]):
#             dist_item = pairwise_distances(
#                 X.reshape((X.shape[0], -1))[i: i + 1, :],
#                 X.reshape((X.shape[0], -1))
#             )
#             sort_index = np.argsort(dist_item)[0][0:5]
#             m = MahalanobisDistance(X[sort_index])
#             for j in range(dist.shape[0]):
#                 dist[i, j] = m(X[i], X[j])
#             alpha = dist[i][sort_index].mean() / distold[i][sort_index].mean()
#             dist[i] = dist[i] / alpha

#         dist = np.power(dist, 2)

#         rho = self._CalRho(dist)

#         r = PoolRunner(
#             number_point=X.shape[0],
#             perplexity=perplexity,
#             dist=dist,
#             rho=rho,
#             gamma=self._CalGamma(v_input),
#             v=v_input,
#             pow=2,
#             func_new=self.func_new)
#         sigma = np.array(r.Getout())

#         std_dis = np.std(rho) / np.sqrt(X.shape[1])
#         logging.info('std_dis: ' + str(std_dis))
#         if std_dis < 0.20 or self.same_sigma:
#             sigma[:] = sigma.mean() * 5
#             rho[:] = 0

#         return rho, sigma

#     def Epsilonball(self, data, epsilon=2):

#         """
#         function used to calculate the distance between point pairs and determine the neighborhood with r-ball
#         Arguments:
#             data {tensor} -- the train data
#         Outputs:
#             d {tensor} -- the distance between point pairs
#             kNN_mask {tensor} a mask used to determine the neighborhood of every data point
#         """

#         # epsilon = self.epsilon

#         x = data.to(self.device)
#         y = data.to(self.device)
#         m, n = x.size(0), y.size(0)
#         xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
#         yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
#         dist = xx + yy
#         # dist.addmm_(1, -2, x, y.t())
#         dist = torch.addmm(dist, mat1=x, mat2=y.t(), beta=1, alpha=-2)
#         d = dist.clamp(min=1e-8).sqrt()

#         kNN_mask = (d < epsilon).bool()

#         return d, kNN_mask


# class MahalanobisDistance():
#     def __init__(self, X):
#         self._PCA = None
#         self._mean_x = np.mean(X, axis=0)
#         X = X.reshape(X.shape[0], -1)
#         mean_removed = X  # - self._mean_x
#         cov = np.cov(mean_removed, rowvar=False)
#         if np.linalg.det(cov) == 0.0:
#             eig_val, eig_vec = np.linalg.eig(cov)
#             e_val_index = np.argsort(-eig_val)
#             e_val_index = e_val_index[e_val_index > 1e-3]
#             self._PCA = eig_vec[:, e_val_index]
#             PCA_X = np.dot(X, self._PCA)
#             self._mean_x = PCA_X.mean(axis=0)
#             mean_removed = PCA_X  # - self._mean_x
#             cov = np.cov(mean_removed, rowvar=False)

#         self._cov_i = np.linalg.inv(cov)

#     def __call__(self, X, y=None):
#         if y is None:
#             y = self._mean_x
#         X_data = X.copy()
#         if self._PCA is not None:
#             X_data = np.dot(X_data, self._PCA)
#         X_data = X_data - y
#         distance = np.dot(np.dot(X_data, self._cov_i), X_data.T)
#         if len(X.shape) != 1:
#             distance = distance.diagonal()

#         return np.sqrt(distance)
