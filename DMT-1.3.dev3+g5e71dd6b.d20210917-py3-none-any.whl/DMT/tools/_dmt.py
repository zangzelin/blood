import numpy as np
import torch
import torch.optim as optim
from torch import nn, tensor
from torch.nn.parallel import DistributedDataParallel as DDP
import torch.distributed as dist
from .dmt_utils import tool
from .dmt_utils.Dataloader import Dataset
import logging

import ssl

ssl._create_default_https_context = ssl._create_unverified_context
# import FlowCal


class dmt():
    def __init__(self,
                 data: tensor,
                 label: tensor,
                 version: int = 1,
                 data_name: str = 'test',
                 perplexity: int = 15,
                 v_input: float = 100,
                 vs: float = 0.001,
                 ve: float = 100,
                 batch_size: int = 2000,
                 epochs: int = 1000,
                 lr: float = 1e-3,
                 log_interval: int = 200,
                 trainquiet: int = 0,
                 method: str = "dmt",
                 NetworkStructure: list = [-1, 500, 300, 2],
                 device: torch.device = None,
                 DEC: bool = False,
                 pow: float = 2,
                 seed: int = 1,
                 lr_iter: list = [500],
                 metric: str = 'euclidean',
                 modelType: str = 'mlp',
                 fb: float = 1,
                 nb: float = 0,
                 path: str = None
                 ):
        super(dmt, self).__init__()

        self.args = {}
        if method not in ['dmt', 'dmt_mask']:
            raise ValueError("Method must be dmt or dmt_mask！")

        self.data_train = data
        self.label_train = label
        self.version = version
        if device:
            if torch.cuda.device_count() > 1:
                dist.init_process_group(backend="nccl")
                local_rank = dist.get_rank()
                logging.info("local rank: {}".format(local_rank))
                torch.cuda.set_device(local_rank)
                self.device = torch.device("cuda", local_rank)
            else:
                self.device = device
        else:
            self.device = torch.device('cpu')

        self.path = path
        self.args['data_name'] = data_name
        self.args['perplexity'] = perplexity
        self.args['v_input'] = v_input
        self.args['vs'] = vs
        self.args['ve'] = ve
        self.args['batch_size'] = batch_size
        self.args['epochs'] = epochs
        self.args['lr'] = lr
        self.args['log_interval'] = log_interval
        self.args['trainquiet'] = trainquiet
        self.args['method'] = method
        self.args['NetworkStructure'] = NetworkStructure
        self.args['pow'] = pow
        self.args['lr_iter'] = lr_iter
        self.args['sigma'] = False if device is None else True
        self.args['DEC'] = DEC

        if self.version == 1:
            # self.args['sigma'] = False
            from .dmt_utils.Dataloader import DatasetV1 as Dataset
            if self.data_train.shape[0] < 50000:
                from .dmt_utils.Model import ELIS110 as Model
                from .dmt_utils.Loss import Loss_v110 as Loss
            else:
                from .dmt_utils.Model import ELIS111 as Model
                from .dmt_utils.Loss import Loss_v111 as Loss

            self.dataset = Dataset(self.data_train, self.label_train, batch_size, device)
            self.Model = Model(self.dataset, self.device, self.args)
            self.Loss = Loss(self.dataset.dist, self.device, self.Model.rho, self.Model.sigmaListlayer, self.Model.gammaList, self.Model.vList, NetworkStructure, perplexity)
        elif self.version == 2:
            from .dmt_utils.Model import LISV2 as Model
            from .dmt_utils.Loss import LossV2 as Loss
            from .dmt_utils.tool import Nushadular
            from .dmt_utils.Dataloader import DatasetV2 as Dataset

            self.dataset = Dataset(self.data_train, self.label_train, batch_size, self.device, model_type=modelType)
            self.Model = Model(self.dataset, self.device, self.args, metric=metric, model_type=modelType)
            self.Loss = Loss(v_input=v_input, fb=fb, nb=nb, device=device)
            self.nushadular = Nushadular(nu_start=vs, nu_end=ve, epoch_start=epochs // 5, epoch_end=epochs * 4 // 5)
        elif self.version == 3:
            pass
        else:
            raise ValueError("version must be 1 or 2！")

        tool.SetSeed(seed)
        self.outem = None
        self.outre = None
        self.optimizer = optim.Adam(self.Model.parameters(), lr=lr)

        if device and torch.cuda.device_count() > 1:
            self.Model = DDP(self.Model, device_ids=[local_rank], output_device=local_rank)
            # self.optimizer = DO(optim.Adam, self.Model.parameters())
        if logging.Handler is not None:
            tool.SaveParam(self.path, self.args)

    def saveModel(self, path: str):
        if dist.get_rank() == 0:
            logging.info('Save current model to ' + path)
            torch.save(self.Model.module.state_dict(), path)

    def loadModel(self, path: str):
        logging.info('Load model ' + path)
        self.Model.module.load_state_dict(torch.load(path))

    def train(self, dataset: Dataset, epoch):
        self.Model.train()
        self.Loss.train()
        train_loss_sum_ = 0
        dataset.reset(epoch)
        while dataset.epochend():
            batch_idx, index_data = dataset.load()

            input_data_model, input_data_loss, label_item = dataset[index_data]

            latent_data = self.Model(input_data_model, index_data)
            self.optimizer.zero_grad()
            if self.version == 1:
                loss, lossrc = self.Loss(input_data_model, latent_data, self.Model.Generate(latent_data.detach()), index_data)
                # print(loss_list, '\n', output, '\n', reom)

                loss.backward()
                lossrc.backward()
            elif self.version == 2:
                # index_data = index_data.detach().cpu()
                rho_item = self.Model.module.rho[index_data]
                sigma_item = self.Model.module.sigma[index_data]
                rho = rho_item.reshape(-1, 1).float().to(self.device)
                sigma = sigma_item.reshape(-1, 1).float().to(self.device)

                # output = self.Model(input_data_model, index_data)
                if self.args['DEC']:
                    r = self.Model.decf(latent_data)

                loss = self.Loss(input_data=input_data_loss,
                                 latent_data=latent_data,
                                 rho=rho,
                                 sigma=sigma,
                                 v_latent=self.nushadular[epoch])

                if self.args['DEC']:
                    cr = nn.MSELoss()
                    l = cr(self.Model.decf(latent_data), input_data_model)
                    loss += l

                # self.optimizer.zero_grad()
                loss.backward()
            self.optimizer.step()
            train_loss_sum_ += loss.item()

        # print(self.Model.vList, self.Model.gammaList)
        if self.version == 1:
            self.Loss.gammaList, self.Loss.vList = self.Model.gammaList, self.Model.vList

        if self.args['trainquiet'] == 0 and (epoch % 100 == 0):
            logging.info('Train Epoch: {} [{}/{} ({:.0f}%)] \t Loss: {}'.format(
                epoch, epoch, self.args['epochs'], 100. * epoch / self.args['epochs'], train_loss_sum_))

        return train_loss_sum_

    def fit(self, preTrain: str = None):
        if preTrain is not None:
            self.loadModel(preTrain)
        for epoch in range(0, self.args['epochs'] + 1):
            self.Model.epoch = epoch
            loss_item = self.train(self.dataset, epoch)
            if self.args['lr_iter']:
                if epoch in self.args['lr_iter']:
                    for param_group in self.optimizer.param_groups:
                        param_group["lr"] = param_group["lr"] / 10
                    logging.warning('change the learning rate, epoch: ' + str(epoch))

    def transform(self, dataset: Dataset, preTrain: str = None):
        if preTrain is not None:
            self.loadModel(preTrain)
        self.Model.eval()
        self.Loss.eval()
        self.outem = np.zeros(shape=(dataset.data.shape[0], 2))
        self.outla = np.zeros(shape=(dataset.data.shape[0]))
        dataset.reset(0)
        while dataset.epochend():
            batch_idx, index_data = dataset.loadAll()
            input_data_model, _, label_data = dataset[index_data]
            latent_data = self.Model(input_data_model, index=index_data)

            index_data = index_data.detach().cpu().numpy()
            self.outem[index_data, :] = latent_data.detach().cpu().numpy()
            self.outla[index_data] = label_data.detach().cpu().numpy()
        # self.sadata.obsm['X_dmtp'] = self.outem

    def fit_transform(self, finData: bool = True, interData: bool = False, preTrain: str = None):
        if preTrain is not None:
            self.loadModel(preTrain)

        # os.chdir(r'./' + self.path)
        # self.dataset.toDevice()
        gifPloterLatentTrain = tool.GIFPloter()
        for epoch in range(0, self.args['epochs'] + 1):
            loss_item = self.train(self.dataset, epoch) if epoch > 0 else 1

            self.Model.epoch = epoch

            if self.args['lr_iter']:
                if epoch in self.args['lr_iter']:
                    for param_group in self.optimizer.param_groups:
                        param_group["lr"] = param_group["lr"] / 10
                    logging.warning('change the learning rate, epoch: ' + str(epoch))

            if interData and epoch % self.args['log_interval'] == 0 and dist.get_rank() == 0:
                self.transform(self.dataset)
                gifPloterLatentTrain.AddNewFig(
                    self.outem,
                    self.label_train.cpu(),
                    his_loss=None,
                    path=self.path,
                    graph=None,
                    link=None,
                    title_='train_epoch_em{}_{}_{}.png'.format(str(epoch).zfill(5), self.args['perplexity'], dist.get_rank())
                )
                self.saveModel(self.path + 'train_epoch{}.model'.format(str(epoch).zfill(6)))

        if finData and dist.get_rank() == 0:
            self.transform(self.dataset)
            self.saveModel(self.path + 'epoch{}.model'.format(str(epoch).zfill(6)))
            gifPloterLatentTrain.AddNewFig(
                self.outem,
                self.label_train.cpu(),
                his_loss=None,
                path=self.path,
                graph=None,
                link=None,
                title_='epoch_em{}_{}_{}.png'.format(str(epoch).zfill(5), self.args['perplexity'], dist.get_rank())
            )
        if interData and dist.get_rank == 0:
            gifPloterLatentTrain.SaveGIF()

        return self.path
